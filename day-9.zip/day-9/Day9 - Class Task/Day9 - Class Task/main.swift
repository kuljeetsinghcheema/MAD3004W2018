//
//  main.swift
//  Day9 - Class Task
//
//  Created by Kuljeet Singh on 2018-02-08.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation


let age = Person(firstname: "ABC", lastname: "XYZ", address: "12 ASDF",Age: 4)

if age.age < 16
{
    print("Not Eligible")
}
else
{
    print("Eligible")
}

Delete

Message
