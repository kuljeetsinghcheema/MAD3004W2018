//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//sorted closure
var months = [4 , 3 , 1 , 6,5,2]
 print(months.sorted())

func reverse(_ s1: Int , _ s2: Int) -> Bool
{
return s1 > s2
}
var reverseMonths = months.sorted(by: reverse)
print("reversedMonths:" , reverseMonths)

/*func increasing(_ s1: Int, _ s2: Int) -> Bool
{
    print("incresing months:" , increasing)
}*/

var reverseClosure = months.sorted(by: {
    (s1: Int , s2: Int) -> Bool in
    return s1 > s2
})
print("reverse closure" , reverseClosure)

//inferring parameter types from context
var inferType = months.sorted(by: {
    //(s1, s2) in return s1 > s2
    (s1, s2)in s1 < s2 //implicit return
})
print("infertype:" , inferType)
//sortHand argument names
print("Short Hand argument", months.sorted(by: {$0 < $1}))

//operator methods
print("operator methods :" ,months.sorted(by: < ))

var three = [1,3,4,5,6,8,9,12,15]
print ("three:" , three)

//
var modThree = three.filter({$0 % 3 == 0})

//nested functions closure
func makeIncrementer(forIncrement amount: Int) -> () -> Int {
    var runningTotal = 0
    
    func incrementer() -> Int
    {
        runningTotal += amount
        return runningTotal
        
    }
    return incrementer
}

let incrementBySeven = makeIncrementer(forIncrement: 7)
print("Increment by seven 1:" , incrementBySeven())
print("Increment by seven 2:" , incrementBySeven())

let incrementByTen = makeIncrementer(forIncrement: 10)
print("first call:" , incrementByTen()) //10
print("second call:" , incrementByTen()) //20
print("third call:" , incrementByTen()) //30
print("fourth call:" , incrementByTen()) //40

//closures are reference type
let incrementBySevenAgain = incrementBySeven
print("increment by seven 3:", incrementBySevenAgain)

//autoClosures
var errorList = [404,414,402,431,455,440]
print("total errors :", errorList.count)

let debugger = { errorList.remove(at: 0)}
print("total errors:", errorList.count)

print("Now solving: \(debugger())")
print("total errors:" , errorList.count)
print("Error list : ", errorList)

/*func someFunctionWithNonescapingClosure(closure: () -> Void) {
    closure()
}

class SomeClass {
    var x = 10
    func doSomething() {
        someFunctionWithEscapingClosure { self.x = 100 }
        someFunctionWithNonescapingClosure { x = 200 }
    }
}

let instance = SomeClass()
instance.doSomething()
print(instance.x)
// Prints "200"

completionHandlers.first()
print(instance.x)
// Prints "100"
*/


//classes and structure in swift

//declaring a structure
struct project{
    var title = " "
    var hours = 0
    
    func display(){
        print("project title:" ,title)
        print("total work hours reqd:" , hours)
    }
}

//declaring instance of structure
var LMSProject = project(title: "Moodle", hours: 200)
print(LMSProject)

LMSProject.display()

//class declaration
class Manager{
    var name: String = " "
    var productOwner: Bool = true
    var currentProjects = project()
}

//creating instance of class
let mgrCanada = Manager()
mgrCanada.name = "JK"
mgrCanada.productOwner = true
mgrCanada.currentProjects = project(title: "sales reporting", hours: 20)

print("mgrCanada name:", mgrCanada.name)
print("mgrCanada Product owner:", mgrCanada.productOwner)
print("mgrcanada current projects:", mgrCanada.currentProjects)

//structures are value types
struct address{
    var street = "265' Yorkland Blvd"
    var city = "north york"
    var postalCode = "M1H1Y1"
}

var lambton = address()
print("Lambton:" , lambton)

var cestar = lambton
//let lambton = cestar
//raise error when change the parameter
print("Cestar:" ,cestar)

cestar.street = "271 yorkland blvd"
cestar.postalCode = "m1h3y3"
print("Cestar:", cestar)

//classes are reference types
class institute{
    var street = "265 yorkland blvd"
    var city = "north york"
    var postalCode = "M1H1Y1"
}

var myLambton = institute()
print("myLanbton street:", myLambton.street)
print("mylambton city:", myLambton.city)

var myCestar = myLambton
print("myCestar street:", myCestar.street)
print("myCestar city:", myCestar.city)

print("myLambton:", myLambton.street)
print("myLambton:", myLambton.postalCode)

//identical to ===
if myLambton === myCestar
{
    print("lambton and cestar are same")
}
else
{
    print("lamnton and cestar are NOT same")
}

var yourCestar = institute()
if yourCestar === myCestar {
    print("yourCestar and myCestar are same")
}
else
{
print("yourCestar and myCestar are NOT same")
}
