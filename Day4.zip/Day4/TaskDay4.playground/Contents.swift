//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

class student
{
    var first_name = "Kuljeet"
    var last_name =  "Singh"
    var age = "21"
}

class postalAddress
{
    var street = "11, Nootka Crescent"
    var city = "North York"
    var postalCode = "M2H2X7"
}

let s1 = student()

print("\(s1.first_name) is of \(s1.age) lives at \("s1.postalAddress.street"), \("sq.postalAddress.city").")
