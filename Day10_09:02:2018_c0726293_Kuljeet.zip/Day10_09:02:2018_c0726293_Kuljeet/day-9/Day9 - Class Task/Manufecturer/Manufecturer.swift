//
//  Manufecturer.swift
//  Day9 - Class Task
//
//  Created by Kuljeet Singh on 2018-02-08.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class manufecturer
{
    var name: String

//designated initializer
init(name: String)
{
    self.name = name
}

convenience init()
{
    self.init(name: "[Unknown]")
}
}
