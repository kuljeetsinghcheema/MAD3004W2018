//
//  Preference.swift
//  Day9 - Class Task
//
//  Created by Kuljeet Singh on 2018-02-08.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class preference: vehicle{
    var perfer = false
    var discription = 
}
