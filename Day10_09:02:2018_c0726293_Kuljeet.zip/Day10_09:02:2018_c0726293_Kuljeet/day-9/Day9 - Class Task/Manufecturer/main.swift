//
//  main.swift
//  Day9 - Class Task
//
//  Created by Kuljeet Singh on 2018-02-08.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

var objManu = manufecturer()
print("\(objManu.name)")

var objVeh = vehicle(name: "car", noOfWheels: 2)
print("vehicle: \(objVeh.name),")

let noObject = vehicle()

let alienVehicle = vehicle(name:"bmw")



