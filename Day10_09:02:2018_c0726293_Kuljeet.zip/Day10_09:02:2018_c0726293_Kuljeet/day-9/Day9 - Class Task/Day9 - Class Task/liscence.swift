//
//  liscence.swift
//  Day9 - Class Task
//
//  Created by Kuljeet Singh on 2018-02-08.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation


class Licence: Person
{
    var LIClocation: String?
    
    override init()
    {
        super.init()
        self.LIClocation = ""
    }
    
    init(firstname: String, lastname: String, address: String, Age: Int, LIClocation: String)
    {
        super.init(firstname: firstname, lastname: lastname, address: address, Age: Age)
        self.LIClocation = LIClocation
    }
}
