//
//  error.swift
//  day10-classActivity
//
//  Created by Kuljeet Singh on 2018-02-09.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

enum speedLimit: Error{
    case declined
    case approved
}

struct ticketAppeal{
    var speed: Double
    var liDate: Double
    var passenger: Bool
    var status: String
}
