//
//  Ticket.swift
//  day10-classActivity
//
//  Created by Kuljeet Singh on 2018-02-09.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class ticket
{
    var ticketRecieved = [
        "C420": ticketAppeal(speed:120, liDate:2, passenger: true, status: "no"),
        "C320": ticketAppeal(speed:190, liDate:3, passenger: true, status: "yes")]

    func makeAppeal(ticketNo tno: String) throws{
       guard let tckapp = ticketRecieved[tno]
       else
       {
        throw speedLimit.declined
        }
        guard tckapp.passenger == false
            else
        {
           throw speedLimit.declined
        }
        guard tckapp.speed < 150
        else
        {
            throw speedLimit.declined
        }
        guard tckapp.liDate > 2
            else
        {
            throw speedLimit.declined
        }
        
        var appealApproved = tckapp
        appealApproved.status = "Approved"
        print("the ticket is approved")
    }
    
}
