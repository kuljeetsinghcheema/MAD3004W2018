//
//  main.swift
//  day10-classActivity
//
//  Created by Kuljeet Singh on 2018-02-09.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

var ticketRequest = ticket()


do
{
    try ticketRequest.makeAppeal(ticketNo: "C420")
}
catch speedLimit.declined
{
    print("You ticket is declied")
}
    
catch speedLimit.approved
{
    print("ticket accpeted")
}
catch
{
    print("no ticket")
}

