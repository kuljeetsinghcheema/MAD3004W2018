//
//  main.swift
//  prime no
//
//  Created by Kuljeet Singh on 2018-02-06.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

print("Day 7- Task1")

var primeNo = 54
print("\(primeNo) : \(primeNo.prime)")

var primeNum = 97
print("\(primeNum) : \(primeNum.prime)")
