//
//  main.swift
//  Day11
//
//  Created by Kuljeet Singh on 2018-02-12.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

print("Hello, World!")

//var objStud = Student()
//objStud.display()

//var objFullTime = FullTime()
//objFullTime.display()


//Can be extended as Internal to the module
//var p1 = PartTime()

//Not possible as fileprivate
//p1.setStudentName("Cheema")

obj.ExtendPT.setStudentName(sname:"Kay Ess")

class T: ExtendPartTime
{
    override init()
    {
        super.init()
        print("Display T")
    }
}
