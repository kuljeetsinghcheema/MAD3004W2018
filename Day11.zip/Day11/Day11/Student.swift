//
//  Student.swift
//  Day11
//
//  Created by Kuljeet Singh on 2018-02-12.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

private class Student
{
    private var sname: String
    init()
    {
        self.sname = "Student name"
    }
    func setStudentName(sname:String) {
        self.sname = sname
    }
    private func display()
    {
        print("ian private method of student class")
    }
    func setStudentName()-> String
    {
        self.sname = sname
    }
    func getStudentName() -> String
    {
        return self.sname
    }
}
    private class FullTime: Student
    {
        var subject: String?
        
        override  init() {
            self.subject = "Fulltime SUbject"
        }
        
        private func setSubject(subject: String)
        {
            self.subject = subject
        }
        
        //private func display()
        fileprivate func display()
        {
            
            //Not possible and not inherited
            //super.display()
            
            
            print("I am method of FullTime Class")
            super.display(message: "FILE PRIVATE")
            
        }
 }
