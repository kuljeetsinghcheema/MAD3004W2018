//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//classes

class Employee {
    var empID: Int?
    var empName: String?
    var basicPay: Double?
   

//initializers
    init() {
        self.empID = 0
        self.empName = " "
        self.basicPay = 0.0
    }
    
    //parameterized initializers
    init(ID:Int, nm:String, pay:Double) {
        self.empID = ID
        self.empName = nm
        self.basicPay = pay

    }

    
    func display()
    {
        print("Employee ID:", self.empID!)
        print("Employee Name:",self.empName!)
        print("basic pay:", self.basicPay!)
    }

//deinitializers
deinit{
    print("Employee object deinitialized")
    }
}

 var emp1 = Employee()
emp1.empID = 101
emp1.empName = "Srijith"
emp1.basicPay = 5000
emp1.display()

emp1.basicPay =  5000
//emp1.display()

var emp3 = Employee ()

emp3.display()

class PermanentEmployee : Employee
{
    var vacationWeeks : Int?

    //default initilizers
    override init() {
    super.init()
    self.vacationWeeks = 0
    }
    
    //parameterized initializer for subclass
    init(eID: Int, eNM: String, ePay: Double, weeks: Int) {
        super.init(ID: eID, nm: eNM, pay: ePay)
        self.vacationWeeks = weeks
    }
    
    override func display() {
        print("vacation weeks:", vacationWeeks!)
    }
}

var obj3 = PermanentEmployee()
obj3.vacationWeeks = 10
//obj2.display()

var obj5 = PermanentEmployee()
//obj5.display()

var obj6 = PermanentEmployee(eID: 106, eNM: "navjot", ePay: 1320.77, weeks: 1)
obj6.display()

/*class payRoll : PermanentEmployee{
    var netPay: Double?{
        get{
            var vw = self.vacationWeeks!
            if vw > 5 {
                return self.basicPay!
            }
        }
    }
}
 */
/* override init(){
    super.init()
    self.netPay = 0
}
init(eID: Int, eNM: String, ePay: Double, weeks: Int)
{
    
}
override func display(){
    
}

var vw = self.vacationWeeks!
if vw > 5{
    self.netPay! = self.basicPay! - 100
}
else
{
    self.netPay! = self.basicPay!
}
*/

var obj7 = PayRoll(eID: 107, eNM: "Prabh", ePay: 2456.23, weeks: 6)
//obj7.display()

//manipulate object array[]
var janPayRoll = [PayRoll]()
let noOfEmployees = 2

for i in 0..<2{
    janPayRoll.append(PayRollPayRoll(eID: 107, eNM: "JK", ePay: 5555.56, weeks: 7))
    janPayRoli[i].display
}


 var obj2 = PermanentEmployee()
obj2.empID = 102
obj2.empName = "tuan"
obj2.basicPay = 30
obj2.display()



