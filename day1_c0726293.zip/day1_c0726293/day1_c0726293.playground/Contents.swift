//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
//terminator terminates the statement there continue the next one along
print("this is our string: \(str)",terminator:" ")
//use sepataor for separating multiple prompts
print("1","2","3","4","5",separator: "\n")
// \n is for next line
print("1","2","3","4","5",separator: "..")
var n1 = 10
print("Number 1 : ",n1,"String : " ,str)
var n2 = 20
print("Number 2 : ",n2)
var sum = n1 + n2
print("sum is : ",sum)
print("Sum =", n1+n1)

/*
 n1= "test"
 print("n1:",n2)
*/

var a:Int = 10
print(" a = ",a)

var Greet:String = "good morning"
print("Greetings : ",Greet)

var emoji = "👳🏻‍♂️";
print ("its a \(emoji) ਸਰਦਾਰ G")

let pi = 3.14
//pi = 3.190
print(" Pi = " , pi)

//var pi = 10

let myNum:Int? //optional
myNum = 10

if myNum != nil {
    print("myNum : ",myNum!)
}
else{
    print("myNum is nil")
}
//optional values
let possibleNumber = "123" //"hello"
let convertedNumber:Int?

convertedNumber = Int(possibleNumber)

if convertedNumber != nil{
    print("Converted Number", convertedNumber!)

}
else{
    print("Converted no. is nil")
}

for i in 1...5 {
    print("i = ", i)
}
let languages:[String]
languages = ["English", "Spanish", "French"]

for i in languages{
    print("language : " , i)
}
var num: Int = 1

for _ in 1...5 {
    num += 5
}
print("answer=", num)

var j = 1

while (j > 5){
    print("Value of j is \(j)")
 j = j + 1
}


var num1 = 10

switch num1 {
case 100 :
    print("Value of num1 is 100")
    
case 10 , 15 :
    print("value of num1 is either 10 or 15")
 
case 5 :
    print("Values of num1 is 5")
    
default :
    print("num not present")
}
